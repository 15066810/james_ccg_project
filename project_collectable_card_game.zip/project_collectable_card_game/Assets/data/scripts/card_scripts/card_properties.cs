﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class card_properties
{
    public string string_value;
    public int int_value;
    public Sprite sprite_value;
    public element element_value;

}
