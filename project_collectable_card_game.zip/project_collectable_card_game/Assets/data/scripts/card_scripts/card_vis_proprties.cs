﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using TMPro;


[System.Serializable]
public class card_vis_properties
{
    public TextMeshProUGUI text;
    public Image image;
    public element element;
    
}
