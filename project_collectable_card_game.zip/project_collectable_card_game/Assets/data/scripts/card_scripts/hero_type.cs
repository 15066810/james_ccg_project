﻿using UnityEngine;
using System.Collections;
using System;

[CreateAssetMenu(menuName = "card_type/hero")]
public class hero_type : card_type
{
    public override void on_set_type(card_vis vis)
    {
        base.on_set_type(vis);
    }
}
