﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class card_type : ScriptableObject
{
    public string type_name;

    public virtual void on_set_type(card_vis vis)
    {
        element t = settings.get_resource_manager().type_element;
        card_vis_properties type = vis.get_properties(t);
        type.text.text = type_name;
    }
}
