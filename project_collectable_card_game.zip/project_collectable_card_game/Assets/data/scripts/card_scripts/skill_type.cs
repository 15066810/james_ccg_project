﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "card_type/skill")]
public class skill_type : card_type
{
    public override void on_set_type(card_vis vis)
    {
        base.on_set_type(vis);
    }
}
