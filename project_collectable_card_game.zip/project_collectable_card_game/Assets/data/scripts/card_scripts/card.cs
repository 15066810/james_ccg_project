﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(menuName = "card")]
public class card : ScriptableObject
{
    public card_type this_card_type;
    public card_properties[] this_card_properties;
}



