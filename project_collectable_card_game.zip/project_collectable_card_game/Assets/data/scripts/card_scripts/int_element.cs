﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "element/int")]
public class int_element : element
{
    
}
