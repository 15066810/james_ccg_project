﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using TMPro;

public class card_vis : MonoBehaviour
{
    public card this_card;
    public card_vis_properties[] vis_properties;


    private void Start()
    {
        load_card(this_card);
    }

    public void load_card(card c)
    {
        if (c == null)
            return;

        this_card = c;

        c.this_card_type.on_set_type(this);

        for(int i = 0; i < c.this_card_properties.Length; i++)
        {
            card_properties cp = c.this_card_properties[i];
            card_vis_properties p = get_properties(cp.element_value);

            if (p == null)
                continue;

            if(cp.element_value is int_element)
            {
                p.text.text = cp.int_value.ToString();
            }
            else if (cp.element_value is text_element)
            {
                p.text.text = cp.string_value;
            }
            else if (cp.element_value is image_element)
            {
                p.image.sprite = cp.sprite_value;
            }
        }

    }

    public card_vis_properties get_properties(element e)
    {
        card_vis_properties result = null;

        for (int i = 0; i< vis_properties.Length; i++)
        {
            if(vis_properties[i].element == e)
            {
                result = vis_properties[i];
                break;
            }
        }

        return result;
    }
}


