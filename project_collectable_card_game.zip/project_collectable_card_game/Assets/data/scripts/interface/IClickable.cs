﻿using UnityEngine;
using System.Collections;

public interface IClickable
{
    void onClick();
    void onHighlight();
}
