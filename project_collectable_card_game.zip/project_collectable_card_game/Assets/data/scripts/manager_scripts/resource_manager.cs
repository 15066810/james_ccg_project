﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(menuName = "manager/resource manager")]
public class resource_manager : ScriptableObject
{
    public element type_element;
}
