﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class game_manager : MonoBehaviour
{
    public game_state current_state;

    private void Update()
    {
        current_state.tick(Time.deltaTime);
    }
}
