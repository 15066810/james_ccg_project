﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public static class settings
{
    private static resource_manager _resource_manager;

    public static resource_manager get_resource_manager()
    {
        if(_resource_manager == null)
        {
            _resource_manager = Resources.Load("resource_manager") as resource_manager;
        }

        return _resource_manager;
    }
}
