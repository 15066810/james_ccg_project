﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "variables/card_variables")]
public class card_variable : ScriptableObject
{
    public card_instance value;

    public void set(card_instance v)
    {
        value = v;
    }
}
