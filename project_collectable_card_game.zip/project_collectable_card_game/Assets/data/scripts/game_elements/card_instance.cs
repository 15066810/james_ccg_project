﻿using UnityEngine;
using System.Collections;
using System;

public class card_instance : MonoBehaviour, IClickable
{
    public card_vis vis;
    public game_element_logic current_logic;

    void start()
    {
        vis = GetComponent<card_vis>();
    }

    public void onClick()
    {
        if (current_logic == null)
            return;

        current_logic.onClick(this);
        // Debug.Log(this.gameObject.name + " clicked");
    }

    public void onHighlight()
    {
        if (current_logic == null)
            return;

        current_logic.onHighlight(this);
        // Debug.Log(this.gameObject.name + " is highlighted");
    }
}
