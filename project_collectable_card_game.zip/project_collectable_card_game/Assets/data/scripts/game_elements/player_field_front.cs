﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "game element/card on field front")]
public class player_field_front : game_element_logic
{
    public override void onClick(card_instance instance)
    {
        Debug.Log("player field front click press detected");
    }

    public override void onHighlight(card_instance instance)
    {

    }
}
