﻿using UnityEngine;
using System.Collections;

public abstract class game_element_logic : ScriptableObject
{
    public abstract void onClick(card_instance instance);
    public abstract void onHighlight(card_instance instance);

}
