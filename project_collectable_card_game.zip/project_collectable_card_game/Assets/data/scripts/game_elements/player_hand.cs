﻿using UnityEngine;
using System.Collections;
using System;

[CreateAssetMenu(menuName = "game element/card in player hand")]
public class player_hand : game_element_logic
{
    public SO.GameEvent on_current_card_selected; //Use script from library
    public card_variable current_card;

    public override void onClick(card_instance instance)
    {
        Debug.Log("player hand click press detected");

        current_card.set(instance);
        on_current_card_selected.Raise(); //Use raise event from library
    }

    public override void onHighlight(card_instance instance)
    {
        
    }
}
