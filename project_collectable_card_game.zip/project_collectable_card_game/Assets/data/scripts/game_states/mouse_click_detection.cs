﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System;
using UnityEngine.EventSystems;

[CreateAssetMenu(menuName = "action/mouse_click_detection")]
public class mouse_click_detection : action
{
    public override void execute(float d)
    {
        if (Input.GetMouseButton(0))
        {
            PointerEventData pointer_data = new PointerEventData(EventSystem.current)
            {
                position = Input.mousePosition
            };

            List<RaycastResult> results = new List<RaycastResult>();
            EventSystem.current.RaycastAll(pointer_data, results);

            foreach (RaycastResult r in results)
            {
                IClickable c = r.gameObject.GetComponentInParent<IClickable>();

                if (c != null)
                {
                    c.onClick();
                    Debug.Log(r.gameObject.name + " click click");
                    break;
                }
                else
                {
                    Debug.Log(r.gameObject.name + "is not clickable");
                }
            }
        }
    }
}