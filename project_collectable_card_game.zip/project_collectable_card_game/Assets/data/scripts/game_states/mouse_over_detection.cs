﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System;
using UnityEngine.EventSystems;

[CreateAssetMenu(menuName = "action/mouse_over_detection")]
public class mouse_over_detection : action
{
    public override void execute(float d)
    {
        PointerEventData pointer_data = new PointerEventData(EventSystem.current)
        {
            position = Input.mousePosition
        };

        List<RaycastResult> results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(pointer_data, results);

        IClickable c = null;

        foreach (RaycastResult r in results)
        {
            c = r.gameObject.GetComponentInParent<IClickable>();
            
            if (c != null)
            {
                c.onHighlight();
                break;
            }
        }
    }
}
