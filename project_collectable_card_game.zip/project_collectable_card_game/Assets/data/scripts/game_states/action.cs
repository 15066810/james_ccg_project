﻿using UnityEngine;
using System.Collections;

public abstract class action : ScriptableObject
{
    public abstract void execute(float d);
}
