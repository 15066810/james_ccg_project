﻿using UnityEngine;
using System.Collections;

[CreateAssetMenu(menuName = "game_state")]
public class game_state : ScriptableObject
{
    public action[] actions;

    public void tick(float d)
    {
        for (int i = 0; i < actions.Length; i++)
        {
            actions[i].execute(d);
        }
    }
}
