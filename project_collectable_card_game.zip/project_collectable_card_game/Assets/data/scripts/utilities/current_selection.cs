﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class current_selection : MonoBehaviour
{
    public card_variable current_card;
    public card_vis current_card_vis;
    Transform current_transform;

    public void load_card()
    {
        if (current_card.value == null)
            return;

        current_card.value.gameObject.SetActive(false);
        current_card_vis.load_card(current_card.value.vis.this_card);
        current_card_vis.gameObject.SetActive(true);
    }

    private void Start()
    {
        current_transform = this.transform;
        current_card_vis.gameObject.SetActive(false);
    }


	void Update()
    {
        current_transform.position = Input.mousePosition;
	}
}
